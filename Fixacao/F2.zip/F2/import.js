const pessoas = require('./exportar.js')
const oi = require('./exportar.js')

console.log(oi)
console.log(exportar.pessoas)