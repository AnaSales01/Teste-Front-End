module.exports = {
    pessoas: 'Olá, pessoas! Tudo bem?',
    tudoBem() {
        return 'Tudo bem?'
    }
}