var times = [
    {
        nome : "Real Madrid",
        pais : "Espanha"
    },
    {
        nome : "Chelse",
        pais : "Inglaterra"
    },
    {
        nome : "Cruzeiro",
        pais : "Brasil"
    }
 ];
 
 var melhores = times.map(function(item, indice){
    return item.nome;
 });
 
 console.log(melhores);